package crime.management;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

public class add_wanted extends javax.swing.JFrame {
    public add_wanted() {
        initComponents();
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        label1 = new java.awt.Label();
        label2 = new java.awt.Label();
        label3 = new java.awt.Label();
        label4 = new java.awt.Label();
        label7 = new java.awt.Label();
        label5 = new java.awt.Label();
        button4 = new java.awt.Button();
        textField4 = new java.awt.TextField();
        textField3 = new java.awt.TextField();
        textField2 = new java.awt.TextField();
        textField1 = new java.awt.TextField();
        button1 = new java.awt.Button();
        button2 = new java.awt.Button();
        button3 = new java.awt.Button();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label1.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        label1.setText("ADD WANTED PERSON. :");
        getContentPane().add(label1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 300, 50));
        label1.getAccessibleContext().setAccessibleName("ADD WANTED CRIMINALS. :");

        label2.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        label2.setText("CRIMINAL'S NAME :");
        getContentPane().add(label2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 230, -1));

        label3.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        label3.setText("CRIMINAL'S AGE  :");
        getContentPane().add(label3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 202, 220, 40));

        label4.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        label4.setText("LAST SEEN LOCATION :");
        getContentPane().add(label4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 292, 280, -1));

        label7.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        label7.setText("BOUNTY  :");
        getContentPane().add(label7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 378, 130, -1));

        label5.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        label5.setText("UPLOAD IMAGE  :");
        getContentPane().add(label5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 464, 210, -1));

        button4.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        button4.setLabel("BROWSE");
        button4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button4ActionPerformed(evt);
            }
        });
        getContentPane().add(button4, new org.netbeans.lib.awtextra.AbsoluteConstraints(416, 464, 240, -1));

        textField4.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        getContentPane().add(textField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(453, 378, 322, -1));
        textField4.getAccessibleContext().setAccessibleName("textField4");

        textField3.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        getContentPane().add(textField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(453, 292, 322, -1));
        textField3.getAccessibleContext().setAccessibleName("textField3");

        textField2.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        getContentPane().add(textField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(453, 206, 322, -1));
        textField2.getAccessibleContext().setAccessibleName("textField2");

        textField1.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        getContentPane().add(textField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(453, 120, 322, -1));
        textField1.getAccessibleContext().setAccessibleName("textField1");

        button1.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        button1.setLabel("ADD");
        button1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button1ActionPerformed(evt);
            }
        });
        getContentPane().add(button1, new org.netbeans.lib.awtextra.AbsoluteConstraints(78, 527, 145, 53));

        button2.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        button2.setLabel("RESET");
        button2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button2ActionPerformed(evt);
            }
        });
        getContentPane().add(button2, new org.netbeans.lib.awtextra.AbsoluteConstraints(356, 527, 161, 53));

        button3.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        button3.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        button3.setLabel("BACK");
        button3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button3ActionPerformed(evt);
            }
        });
        getContentPane().add(button3, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 527, 163, 53));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/crime/management/img/Wanted-Banner-Countdown.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1200, 600));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void button4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button4ActionPerformed
        JFileChooser file = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter("*.Images", ".jpg", ".png", ".gif", ".jpeg");
        int result = file.showSaveDialog(null);
        if(result == JFileChooser.APPROVE_OPTION)
        {
            try
            {
                File selectedFile = file.getSelectedFile();
                String path = selectedFile.getAbsolutePath();
                BufferedImage image = null;
                File imagefile = new File(path);
                image = ImageIO.read(imagefile);
                File f1 = new File("DATA/WANTED CRIMINALS/1");
                f1.mkdirs();
                ImageIO.write(image, "jpeg", new File("DATA/WANTED CRIMINALS/1/1.jpeg"));

            } catch (IOException ex)
            {
                JOptionPane.showMessageDialog(textField1, "PLEASE SELECT AN IMAGE. "+ex.getMessage());
                this.dispose();
            }
        }
        else if(result == JFileChooser.CANCEL_OPTION)
        {
            JOptionPane.showMessageDialog(textField1, "NO IMAGE SELECTED");
        }
    }//GEN-LAST:event_button4ActionPerformed

    private void button1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button1ActionPerformed
        String str1,str2,str3,str4;
        str1=label2.getText()+":"+textField1.getText()+"\r\n";
        str2=label3.getText()+":"+textField2.getText()+"\r\n";
        str3=label4.getText()+":"+textField3.getText()+"\r\n";
        str4=label7.getText()+":"+textField4.getText()+"\r\n";
        byte bb1[]=str1.getBytes();
        byte bb2[]=str2.getBytes();
        byte bb3[]=str3.getBytes();
        byte bb4[]=str4.getBytes();
        try{
            File f1 = new File("DATA/WANTED CRIMINALS/1");
            f1.mkdirs();
            FileOutputStream f= new FileOutputStream("DATA/WANTED CRIMINALS/1/1.txt");
            f.write(bb1);
            f.write(bb2);
            f.write(bb3);
            f.write(bb4);

            JOptionPane.showMessageDialog(textField1, "DATA ENTERED SUCCESSFULLY");
            this.dispose();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(textField1, "DATA ENTERING UNSUCCESSFUL "+e.getMessage());
            this.dispose();
        }
    }//GEN-LAST:event_button1ActionPerformed

    private void button2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button2ActionPerformed
        textField1.setText("");
        textField2.setText("");
        textField3.setText("");
        textField4.setText("");
    }//GEN-LAST:event_button2ActionPerformed

    private void button3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button3ActionPerformed
        this.dispose();
    }//GEN-LAST:event_button3ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new add_wanted().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Button button1;
    private java.awt.Button button2;
    private java.awt.Button button3;
    private java.awt.Button button4;
    private javax.swing.JLabel jLabel1;
    private java.awt.Label label1;
    private java.awt.Label label2;
    private java.awt.Label label3;
    private java.awt.Label label4;
    private java.awt.Label label5;
    private java.awt.Label label7;
    private java.awt.TextField textField1;
    private java.awt.TextField textField2;
    private java.awt.TextField textField3;
    private java.awt.TextField textField4;
    // End of variables declaration//GEN-END:variables
}
