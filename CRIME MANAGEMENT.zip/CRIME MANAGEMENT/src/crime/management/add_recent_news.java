package crime.management;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

public class add_recent_news extends javax.swing.JFrame {
    public add_recent_news() {
        initComponents();
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        label1 = new java.awt.Label();
        label5 = new java.awt.Label();
        label2 = new java.awt.Label();
        button1 = new java.awt.Button();
        button2 = new java.awt.Button();
        button3 = new java.awt.Button();
        button4 = new java.awt.Button();
        button5 = new java.awt.Button();
        textField1 = new java.awt.TextField();
        textField2 = new java.awt.TextField();
        textField3 = new java.awt.TextField();
        textField4 = new java.awt.TextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label1.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        label1.setText("ADD RECENT NEWS. :");
        getContentPane().add(label1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 270, 50));

        label5.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        label5.setText("NEWS 2  :");
        getContentPane().add(label5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 290, 120, -1));

        label2.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        label2.setText("NEWS 1 :");
        getContentPane().add(label2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 125, 120, -1));

        button1.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        button1.setLabel("RESET");
        button1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button1ActionPerformed(evt);
            }
        });
        getContentPane().add(button1, new org.netbeans.lib.awtextra.AbsoluteConstraints(445, 482, 168, 52));

        button2.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        button2.setLabel("CANCEL");
        button2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button2ActionPerformed(evt);
            }
        });
        getContentPane().add(button2, new org.netbeans.lib.awtextra.AbsoluteConstraints(752, 482, 168, 52));

        button3.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        button3.setLabel("ADD");
        button3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button3ActionPerformed(evt);
            }
        });
        getContentPane().add(button3, new org.netbeans.lib.awtextra.AbsoluteConstraints(117, 482, 168, 52));

        button4.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        button4.setLabel("BROWSE");
        button4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button4ActionPerformed(evt);
            }
        });
        getContentPane().add(button4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 360, -1, 34));

        button5.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        button5.setLabel("BROWSE");
        button5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button5ActionPerformed(evt);
            }
        });
        getContentPane().add(button5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 180, -1, 36));

        textField1.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        getContentPane().add(textField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(283, 287, 618, 36));
        textField1.getAccessibleContext().setAccessibleName("textField1");

        textField2.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        getContentPane().add(textField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(283, 125, 618, 36));
        textField2.getAccessibleContext().setAccessibleName("textField2");

        textField3.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        getContentPane().add(textField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(283, 341, 618, 106));
        textField3.getAccessibleContext().setAccessibleName("textField3");

        textField4.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        getContentPane().add(textField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(283, 171, 618, 106));
        textField4.getAccessibleContext().setAccessibleName("textField4");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/crime/management/img/News-Image.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1200, 600));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void button3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button3ActionPerformed
        String str1,str2,str3,str4;
        str1=label2.getText()+":"+textField2.getText()+"\r\n";
        str3=textField3.getText()+"\r\n";
        str2=label5.getText()+":"+textField1.getText()+"\r\n";
        str4=textField4.getText()+"\r\n";
        byte bb1[]=str1.getBytes();
        byte bb2[]=str2.getBytes();
        byte bb3[]=str3.getBytes();
        byte bb4[]=str4.getBytes();
        try{
            File f = new File("DATA/NEWS/1");
            f.mkdirs();
            FileOutputStream f1= new FileOutputStream("DATA/NEWS/1/1.txt");
            f1.write(bb1);
            f1.write(bb3);
            f1.close();
            File f3 = new File("DATA/NEWS/2");
            f3.mkdirs();
            FileOutputStream f2= new FileOutputStream("DATA/NEWS/2/2.txt");
            f2.write(bb2);
            f2.write(bb4);
            f2.close();            
            
            JOptionPane.showMessageDialog(textField1, "DATA ENTERED SUCCESSFULLY");
            this.dispose();
           }
        catch(IOException e)
           {
            JOptionPane.showMessageDialog(textField1, "DATA ENTERING UNSUCCESSFUL"+e.getMessage());
            this.dispose();
           }    
        
    }//GEN-LAST:event_button3ActionPerformed

    private void button5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button5ActionPerformed
        JFileChooser file = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter("*.Images", ".jpg", ".png", ".gif", ".jpeg");
        int result = file.showSaveDialog(null);
        if(result == JFileChooser.APPROVE_OPTION)
        {
            try
            {
                File selectedFile = file.getSelectedFile();
                String path = selectedFile.getAbsolutePath();
                BufferedImage image = null;
                File imagefile = new File(path);
                image = ImageIO.read(imagefile);
                File f1 = new File("DATA/NEWS/1");
                f1.mkdirs();
                ImageIO.write(image, "jpeg", new File("DATA/NEWS/1/1.jpeg"));

            } catch (IOException ex)
            {
                JOptionPane.showMessageDialog(textField1, "PLEASE SELECT AN IMAGE. "+ex.getMessage());
                this.dispose();
            }
        }
        else if(result == JFileChooser.CANCEL_OPTION)
        {
            JOptionPane.showMessageDialog(textField1, "NO IMAGE SELECTED");
        }
    }//GEN-LAST:event_button5ActionPerformed

    private void button4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button4ActionPerformed
       JFileChooser file = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter("*.Images", ".jpg", ".png", ".gif", ".jpeg");
        int result = file.showSaveDialog(null);
        if(result == JFileChooser.APPROVE_OPTION)
        {
            try
            {
                File selectedFile = file.getSelectedFile();
                String path = selectedFile.getAbsolutePath();
                BufferedImage image = null;
                File imagefile = new File(path);
                image = ImageIO.read(imagefile);
                File f1 = new File("DATA/NEWS/2");
                f1.mkdirs();
                ImageIO.write(image, "jpeg", new File("DATA/NEWS/2/2.jpeg"));

            } catch (IOException ex)
            {
                JOptionPane.showMessageDialog(textField1, "PLEASE SELECT AN IMAGE. "+ex.getMessage());
                this.dispose();
            }
        }
        else if(result == JFileChooser.CANCEL_OPTION)
        {
            JOptionPane.showMessageDialog(textField1, "NO IMAGE SELECTED");
        }
    }//GEN-LAST:event_button4ActionPerformed

    private void button1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button1ActionPerformed
        textField1.setText("");
        textField2.setText("");
        textField3.setText("");
        textField4.setText("");
    }//GEN-LAST:event_button1ActionPerformed

    private void button2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button2ActionPerformed
        this.dispose();
    }//GEN-LAST:event_button2ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new add_recent_news().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Button button1;
    private java.awt.Button button2;
    private java.awt.Button button3;
    private java.awt.Button button4;
    private java.awt.Button button5;
    private javax.swing.JLabel jLabel1;
    private java.awt.Label label1;
    private java.awt.Label label2;
    private java.awt.Label label5;
    private java.awt.TextField textField1;
    private java.awt.TextField textField2;
    private java.awt.TextField textField3;
    private java.awt.TextField textField4;
    // End of variables declaration//GEN-END:variables
}
