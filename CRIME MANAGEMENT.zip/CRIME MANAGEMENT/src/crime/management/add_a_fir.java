package crime.management;

import java.io.File;
import java.io.FileOutputStream;
import javax.swing.JOptionPane;

public class add_a_fir extends javax.swing.JFrame {
    public add_a_fir() {
        initComponents();
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        label1 = new java.awt.Label();
        label2 = new java.awt.Label();
        textField1 = new java.awt.TextField();
        textField2 = new java.awt.TextField();
        label5 = new java.awt.Label();
        label4 = new java.awt.Label();
        label7 = new java.awt.Label();
        label3 = new java.awt.Label();
        label6 = new java.awt.Label();
        button1 = new java.awt.Button();
        button2 = new java.awt.Button();
        button3 = new java.awt.Button();
        textField6 = new java.awt.TextField();
        textField5 = new java.awt.TextField();
        textField4 = new java.awt.TextField();
        textField3 = new java.awt.TextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label1.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        label1.setText("ADD A F.I.R. :");
        getContentPane().add(label1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 160, 50));

        label2.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        label2.setText(" VICTIM'S NAME :");
        getContentPane().add(label2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 98, 210, -1));

        textField1.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        getContentPane().add(textField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(447, 98, 720, -1));
        textField1.getAccessibleContext().setAccessibleName("textField1");

        textField2.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        getContentPane().add(textField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(447, 159, 720, -1));
        textField2.getAccessibleContext().setAccessibleName("textField2");

        label5.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        label5.setText(" VICTIM'S AGE  :");
        getContentPane().add(label5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, 190, -1));

        label4.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        label4.setText(" ACCUSE NAME :");
        getContentPane().add(label4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 200, -1));

        label7.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        label7.setText(" ACCUSE AGE  :");
        getContentPane().add(label7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 281, 190, -1));

        label3.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        label3.setText(" AREA(where occured)  :");
        getContentPane().add(label3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, 280, -1));

        label6.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        label6.setText(" DESCRIPTION  :");
        getContentPane().add(label6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 403, 210, -1));

        button1.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        button1.setLabel("ADD");
        button1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button1ActionPerformed(evt);
            }
        });
        getContentPane().add(button1, new org.netbeans.lib.awtextra.AbsoluteConstraints(148, 526, 145, 53));

        button2.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        button2.setLabel("RESET");
        button2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button2ActionPerformed(evt);
            }
        });
        getContentPane().add(button2, new org.netbeans.lib.awtextra.AbsoluteConstraints(473, 526, 161, 53));

        button3.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        button3.setLabel("BACK");
        button3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button3ActionPerformed(evt);
            }
        });
        getContentPane().add(button3, new org.netbeans.lib.awtextra.AbsoluteConstraints(808, 526, 163, 53));

        textField6.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        textField6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textField6ActionPerformed(evt);
            }
        });
        getContentPane().add(textField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(447, 403, 720, 99));
        textField6.getAccessibleContext().setAccessibleName("textField6");

        textField5.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        getContentPane().add(textField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(447, 342, 720, -1));
        textField5.getAccessibleContext().setAccessibleName("textField5");

        textField4.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        textField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textField4ActionPerformed(evt);
            }
        });
        getContentPane().add(textField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(447, 281, 720, -1));
        textField4.getAccessibleContext().setAccessibleName("textField4");

        textField3.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        getContentPane().add(textField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(447, 220, 720, -1));
        textField3.getAccessibleContext().setAccessibleName("textField3");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/crime/management/img/FIR-logo.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1200, 600));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void button2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button2ActionPerformed
        textField1.setText("");
        textField2.setText("");
        textField3.setText("");
        textField4.setText("");
        textField5.setText("");
        textField6.setText("");
    }//GEN-LAST:event_button2ActionPerformed

    private void button3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button3ActionPerformed
        this.dispose();
    }//GEN-LAST:event_button3ActionPerformed

    private void textField6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textField6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textField6ActionPerformed

    private void button1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button1ActionPerformed
        String str1,str2,str3,str4,str5,str6;
        str1=label2.getText()+":"+textField1.getText()+"\r\n";
        str2=label3.getText()+":"+textField2.getText()+"\r\n";
        str3=label4.getText()+":"+textField3.getText()+"\r\n";
        str4=label5.getText()+":"+textField4.getText()+"\r\n";
        str5=label6.getText()+":"+textField5.getText()+"\r\n";
        str6=label7.getText()+":"+textField6.getText()+"\r\n";
        byte bb1[]=str1.getBytes();
        byte bb2[]=str2.getBytes();
        byte bb3[]=str3.getBytes();
        byte bb4[]=str4.getBytes();
        byte bb5[]=str5.getBytes();
        byte bb6[]=str6.getBytes();
        try{
            File f1 = new File("DATA/F.I.R./"+textField1.getText());
            f1.mkdirs();
            FileOutputStream f= new FileOutputStream("DATA/F.I.R./"+textField1.getText()+"/"+textField1.getText()+".txt");
            f.write(bb1);
            f.write(bb2);
            f.write(bb3);
            f.write(bb4);
            f.write(bb5);
            f.write(bb6);
            JOptionPane.showMessageDialog(textField1, "DATA ENTERED SUCCESSFULLY");
            this.dispose();
           }
        catch(Exception e)
           {
            JOptionPane.showMessageDialog(textField1, "DATA ENTERING UNSUCCESSFUL"+e.getMessage());
            this.dispose();
           }     
    }//GEN-LAST:event_button1ActionPerformed

    private void textField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textField4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textField4ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new add_a_fir().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Button button1;
    private java.awt.Button button2;
    private java.awt.Button button3;
    private javax.swing.JLabel jLabel1;
    private java.awt.Label label1;
    private java.awt.Label label2;
    private java.awt.Label label3;
    private java.awt.Label label4;
    private java.awt.Label label5;
    private java.awt.Label label6;
    private java.awt.Label label7;
    private java.awt.TextField textField1;
    private java.awt.TextField textField2;
    private java.awt.TextField textField3;
    private java.awt.TextField textField4;
    private java.awt.TextField textField5;
    private java.awt.TextField textField6;
    // End of variables declaration//GEN-END:variables
}
