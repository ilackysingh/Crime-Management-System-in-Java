package crime.management;
import javax.swing.JOptionPane;
public class police_login extends javax.swing.JFrame {
    public police_login() {
        initComponents();
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        label1 = new java.awt.Label();
        label2 = new java.awt.Label();
        label3 = new java.awt.Label();
        button1 = new java.awt.Button();
        button2 = new java.awt.Button();
        button3 = new java.awt.Button();
        jPasswordField1 = new javax.swing.JPasswordField();
        jTextField1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label1.setFont(new java.awt.Font("Calibri Light", 1, 55)); // NOI18N
        label1.setText("POLICE LOGIN PAGE");
        getContentPane().add(label1, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 80, 574, -1));

        label2.setFont(new java.awt.Font("Calibri Light", 0, 36)); // NOI18N
        label2.setText("ENTER LOGIN ID :");
        getContentPane().add(label2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 270, 330, 52));

        label3.setFont(new java.awt.Font("Calibri Light", 0, 36)); // NOI18N
        label3.setText("ENTER PASSWORD :");
        getContentPane().add(label3, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 350, 380, 52));
        label3.getAccessibleContext().setAccessibleName("ENTER  PASSWORD :");

        button1.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        button1.setLabel("LOGIN");
        button1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button1ActionPerformed(evt);
            }
        });
        getContentPane().add(button1, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 460, 130, 60));

        button2.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        button2.setLabel("RESET");
        button2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button2ActionPerformed(evt);
            }
        });
        getContentPane().add(button2, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 460, 150, 60));

        button3.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        button3.setLabel("BACK");
        button3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button3ActionPerformed(evt);
            }
        });
        getContentPane().add(button3, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 460, 150, 60));

        jPasswordField1.setFont(new java.awt.Font("Calibri Light", 0, 36)); // NOI18N
        getContentPane().add(jPasswordField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 350, 302, 52));
        jPasswordField1.getAccessibleContext().setAccessibleName("jPasswordField1");

        jTextField1.setFont(new java.awt.Font("Calibri Light", 0, 36)); // NOI18N
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 260, 302, 52));
        jTextField1.getAccessibleContext().setAccessibleName("jTextField1");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/crime/management/img/videoblocks-crime-scene-do-not-enter-police-tape-sign-murder-investigation-with-forensic-scientist-in-the-background-collecting-evidence-taking-photographs-domestic-violence-outside-a-house-in-the-daytime.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1200, 600));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void button3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button3ActionPerformed
        this.dispose();
    }//GEN-LAST:event_button3ActionPerformed

    private void button2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button2ActionPerformed
        jTextField1.setText("");
        jPasswordField1.setText("");
    }//GEN-LAST:event_button2ActionPerformed

    private void button1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button1ActionPerformed
        String uname=jTextField1.getText();
        String pwd=jPasswordField1.getText();
        
        if(uname.equals("police") && pwd.equals("admin"))
        {
            JOptionPane.showMessageDialog(jTextField1, "LOGIN SUCCESSFUL");
            new POLICE().setVisible(true);
            jTextField1.setText("");
            jPasswordField1.setText("");
        }
        else
            JOptionPane.showMessageDialog(jTextField1, "LOGIN UNSUCCESSFUL");
            jTextField1.setText("");
            jPasswordField1.setText("");
    }//GEN-LAST:event_button1ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new police_login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Button button1;
    private java.awt.Button button2;
    private java.awt.Button button3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JTextField jTextField1;
    private java.awt.Label label1;
    private java.awt.Label label2;
    private java.awt.Label label3;
    // End of variables declaration//GEN-END:variables
}