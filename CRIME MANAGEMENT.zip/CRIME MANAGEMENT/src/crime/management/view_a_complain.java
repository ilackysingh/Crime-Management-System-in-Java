package crime.management;

import java.io.BufferedReader;
import java.io.FileReader;
import javax.swing.JOptionPane;

public class view_a_complain extends javax.swing.JFrame {
    public view_a_complain() {
        initComponents();
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        label1 = new java.awt.Label();
        label2 = new java.awt.Label();
        button3 = new java.awt.Button();
        button1 = new java.awt.Button();
        button2 = new java.awt.Button();
        textArea1 = new java.awt.TextArea();
        textField1 = new java.awt.TextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label1.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        label1.setText("COMPLAIN STATUS :");
        getContentPane().add(label1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 250, 50));

        label2.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        label2.setText("ENTER A KEYWORD TO SEARCH :");
        getContentPane().add(label2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 125, 414, -1));

        button3.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        button3.setLabel("SEARCH");
        button3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button3ActionPerformed(evt);
            }
        });
        getContentPane().add(button3, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 200, 168, 52));

        button1.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        button1.setLabel("RESET");
        button1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button1ActionPerformed(evt);
            }
        });
        getContentPane().add(button1, new org.netbeans.lib.awtextra.AbsoluteConstraints(419, 200, 168, 52));

        button2.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        button2.setLabel("CANCEL");
        button2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button2ActionPerformed(evt);
            }
        });
        getContentPane().add(button2, new org.netbeans.lib.awtextra.AbsoluteConstraints(744, 200, 168, 52));

        textArea1.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        getContentPane().add(textArea1, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 294, 1146, 296));
        textArea1.getAccessibleContext().setAccessibleName("textArea1");

        textField1.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        getContentPane().add(textField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(622, 125, 386, -1));
        textField1.getAccessibleContext().setAccessibleName("textField1");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/crime/management/img/5498727A-4C2E-426D-851C5BB1EB5FC5B8_source.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1200, 600));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void button3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button3ActionPerformed
        try
        {
            String one,two = "";
            FileReader fr = new FileReader("DATA/COMPLAIN/"+textField1.getText()+"/"+textField1.getText()+".txt");
            BufferedReader in = new BufferedReader(fr);
            while((one= in.readLine())!=null)
            {
                two = (two +"\n" +one);
            }
            textArea1.setText(two);
            JOptionPane.showMessageDialog(textField1, "DATA READING SUCCESSFUL");
            
          
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(textField1, "DATA READING UNSUCCESSFUL"+e.getMessage());
        }
    }//GEN-LAST:event_button3ActionPerformed

    private void button2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button2ActionPerformed
        this.dispose();
    }//GEN-LAST:event_button2ActionPerformed

    private void button1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button1ActionPerformed
        textField1.setText("");
        textArea1.setText("");
    }//GEN-LAST:event_button1ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new view_a_complain().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Button button1;
    private java.awt.Button button2;
    private java.awt.Button button3;
    private javax.swing.JLabel jLabel1;
    private java.awt.Label label1;
    private java.awt.Label label2;
    private java.awt.TextArea textArea1;
    private java.awt.TextField textField1;
    // End of variables declaration//GEN-END:variables
}
