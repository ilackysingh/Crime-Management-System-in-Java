package crime.management;
public class CRIMEMANAGEMENT
{
    public static void main(String[] args) 
    {
        java.awt.EventQueue.invokeLater(new Runnable() 
        {
            public void run() 
            {
                new HOME().setVisible(true);
            }
        });
    }
    
}
