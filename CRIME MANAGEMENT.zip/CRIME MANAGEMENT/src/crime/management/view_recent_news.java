package crime.management;

import java.awt.Component;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
public class view_recent_news extends javax.swing.JFrame {
    private Object textArea1;
    public view_recent_news() {
        initComponents();
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        label1 = new java.awt.Label();
        button2 = new java.awt.Button();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        button3 = new java.awt.Button();
        textArea2 = new java.awt.TextArea();
        textArea3 = new java.awt.TextArea();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label1.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        label1.setText("RECENT NEWS. :");
        getContentPane().add(label1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 210, 50));

        button2.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        button2.setLabel("CANCEL");
        button2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button2ActionPerformed(evt);
            }
        });
        getContentPane().add(button2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1006, 10, 168, 52));
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(89, 117, 377, 314));
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(713, 117, 378, 303));

        button3.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        button3.setLabel("SHOW");
        button3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button3ActionPerformed(evt);
            }
        });
        getContentPane().add(button3, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 10, 140, 52));

        textArea2.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        getContentPane().add(textArea2, new org.netbeans.lib.awtextra.AbsoluteConstraints(713, 451, 377, 100));
        textArea2.getAccessibleContext().setAccessibleName("textArea2");

        textArea3.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        getContentPane().add(textArea3, new org.netbeans.lib.awtextra.AbsoluteConstraints(99, 456, 373, 98));
        textArea3.getAccessibleContext().setAccessibleName("textArea3");

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/crime/management/img/news-426892_960_720.jpg"))); // NOI18N
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1210, 600));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void button3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button3ActionPerformed
        try
        {
            String one,two = "";
            String three,four = "";
            FileReader fr = new FileReader("DATA/NEWS/1/1.txt");
            BufferedReader in = new BufferedReader(fr);
            while((one= in.readLine())!=null)
            {
                two = (two +"\n" +one);
            }
            textArea3.setText(two);
            File fr1 = new File("DATA/NEWS/1/1.jpeg");
            BufferedImage image = null;
            image = ImageIO.read(fr1);
            ImageIcon icon = new ImageIcon(image);
            jLabel1.setIcon(icon);
            
            FileReader fr2 = new FileReader("DATA/NEWS/2/2.txt");
            BufferedReader input = new BufferedReader(fr2);
            while((three= input.readLine())!=null)
            {
                four = (four +"\n" +three);
            }
            textArea2.setText(four);
            File fr3 = new File("DATA/NEWS/2/2.jpeg");
            BufferedImage img = null;
            img = ImageIO.read(fr1);
            ImageIcon icon1 = new ImageIcon(img);
            jLabel2.setIcon(icon1);
            Component textField1 = null;
            JOptionPane.showMessageDialog(textField1, "DATA READING SUCCESSFUL");
        }
        catch(Exception e)
        {
            Component textField1 = null;
            JOptionPane.showMessageDialog(textField1, "DATA READING UNSUCCESSFUL"+e.getMessage());
        }
    }//GEN-LAST:event_button3ActionPerformed

    private void button2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button2ActionPerformed
        this.dispose();
    }//GEN-LAST:event_button2ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new view_recent_news().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Button button2;
    private java.awt.Button button3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private java.awt.Label label1;
    private java.awt.TextArea textArea2;
    private java.awt.TextArea textArea3;
    // End of variables declaration//GEN-END:variables
}
