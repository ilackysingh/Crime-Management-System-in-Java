package crime.management;
import javax.swing.JOptionPane;
public class citizen_login extends javax.swing.JFrame {
    public citizen_login() {
        initComponents();
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        label1 = new java.awt.Label();
        label2 = new java.awt.Label();
        label3 = new java.awt.Label();
        button1 = new java.awt.Button();
        button2 = new java.awt.Button();
        button3 = new java.awt.Button();
        jTextField1 = new javax.swing.JTextField();
        jPasswordField1 = new javax.swing.JPasswordField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1200, 600));
        setSize(new java.awt.Dimension(1200, 600));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label1.setFont(new java.awt.Font("Calibri Light", 1, 55)); // NOI18N
        label1.setText("CITIZEN'S LOGIN PAGE");
        getContentPane().add(label1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 40, 627, 60));

        label2.setFont(new java.awt.Font("Calibri Light", 0, 36)); // NOI18N
        label2.setName("label2"); // NOI18N
        label2.setText("ENTER LOGIN ID :");
        getContentPane().add(label2, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 170, 366, 64));

        label3.setFont(new java.awt.Font("Calibri Light", 0, 36)); // NOI18N
        label3.setText("ENTER PASSWORD :");
        getContentPane().add(label3, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 300, 366, 62));

        button1.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        button1.setLabel("LOGIN");
        button1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button1ActionPerformed(evt);
            }
        });
        getContentPane().add(button1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 470, 155, 53));

        button2.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        button2.setLabel("RESET");
        button2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button2ActionPerformed(evt);
            }
        });
        getContentPane().add(button2, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 470, 161, 53));

        button3.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        button3.setLabel("BACK");
        button3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button3ActionPerformed(evt);
            }
        });
        getContentPane().add(button3, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 470, 163, 53));

        jTextField1.setFont(new java.awt.Font("Calibri Light", 0, 36)); // NOI18N
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 170, 295, 64));
        jTextField1.getAccessibleContext().setAccessibleName("jTextField1");

        jPasswordField1.setFont(new java.awt.Font("Calibri Light", 0, 36)); // NOI18N
        jPasswordField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPasswordField1ActionPerformed(evt);
            }
        });
        getContentPane().add(jPasswordField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 300, 295, 62));
        jPasswordField1.getAccessibleContext().setAccessibleName("jPasswordField1");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/crime/management/img/login.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1200, 600));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void button3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button3ActionPerformed
        this.dispose();
    }//GEN-LAST:event_button3ActionPerformed

    private void jPasswordField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPasswordField1ActionPerformed
        
    }//GEN-LAST:event_jPasswordField1ActionPerformed

    private void button2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button2ActionPerformed
        jTextField1.setText("");
        jPasswordField1.setText("");
    }//GEN-LAST:event_button2ActionPerformed

    private void button1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button1ActionPerformed
        String uname=jTextField1.getText();
        String pwd=jPasswordField1.getText();
        
        if(uname.equals("citizen") && pwd.equals("admin"))
        {
            JOptionPane.showMessageDialog(jTextField1, "LOGIN SUCCESSFUL");
            new CITIZEN().setVisible(true);
            jTextField1.setText("");
            jPasswordField1.setText("");
        }
        else
            JOptionPane.showMessageDialog(jTextField1, "LOGIN UNSUCCESSFUL");
            jTextField1.setText("");
            jPasswordField1.setText("");
    }//GEN-LAST:event_button1ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new citizen_login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Button button1;
    private java.awt.Button button2;
    private java.awt.Button button3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JTextField jTextField1;
    private java.awt.Label label1;
    private java.awt.Label label2;
    private java.awt.Label label3;
    // End of variables declaration//GEN-END:variables
}