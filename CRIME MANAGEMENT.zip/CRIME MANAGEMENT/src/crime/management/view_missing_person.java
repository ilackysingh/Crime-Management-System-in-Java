package crime.management;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;
import javax.swing.*;
public class view_missing_person extends javax.swing.JFrame {
    public view_missing_person() {
        initComponents();
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        label1 = new java.awt.Label();
        button2 = new java.awt.Button();
        textArea1 = new java.awt.TextArea();
        jLabel1 = new javax.swing.JLabel();
        button3 = new java.awt.Button();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label1.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        label1.setText("MISSING PERSON :");
        getContentPane().add(label1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 230, 50));

        button2.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        button2.setLabel("BACK");
        button2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button2ActionPerformed(evt);
            }
        });
        getContentPane().add(button2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 10, 157, 50));

        textArea1.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        getContentPane().add(textArea1, new org.netbeans.lib.awtextra.AbsoluteConstraints(729, 86, 375, 468));
        textArea1.getAccessibleContext().setAccessibleName("textArea1");

        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(106, 86, 386, 468));

        button3.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        button3.setLabel("SHOW");
        button3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button3ActionPerformed(evt);
            }
        });
        getContentPane().add(button3, new org.netbeans.lib.awtextra.AbsoluteConstraints(838, 10, 140, 50));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/crime/management/img/xmissing-person-AdobeStock_73108195-1200x600.jpg.pagespeed.ic_.muS7XeAq20.jpg"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1200, 600));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void button3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button3ActionPerformed
        try
        {
            String one,two = "";
            Component textField1 = null;
            FileReader fr = new FileReader("DATA/MISSING PERSON/1/1.txt");
            BufferedReader in = new BufferedReader(fr);
            while((one= in.readLine())!=null)
            {
                two = (two +"\n" +one);
            }
            textArea1.setText(two);
            File fr1 = new File("DATA/MISSING PERSON/1/1.jpeg");
            BufferedImage image = null;
            image = ImageIO.read(fr1);
            ImageIcon icon = new ImageIcon(image);
            jLabel1.setIcon(icon);
            JOptionPane.showMessageDialog(textField1, "DATA READING SUCCESSFUL");
        }
        catch(Exception e)
        {
            Component textField1 = null;
            JOptionPane.showMessageDialog(textField1, "DATA READING UNSUCCESSFUL"+e.getMessage());
        }

    }//GEN-LAST:event_button3ActionPerformed

    private void button2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button2ActionPerformed
        this.dispose();
    }//GEN-LAST:event_button2ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new view_missing_person().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Button button2;
    private java.awt.Button button3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private java.awt.Label label1;
    private java.awt.TextArea textArea1;
    // End of variables declaration//GEN-END:variables
}
